use Test::More;

sub writeDescription{
	local $F;
	local $write = shift;
	open $F,'>','description' or die $!;
	print $F $write;
	close $F or die $!;
}

sub getCode {
	local $F;
	local $name = shift;
	local $code;
	open $F,$name or die $!;
	local $code;
	{
		local $/;
		$code = <$F>;
	}
	close $F or die $!;
	return $code;
}
$forPerl = '
comment
-start ""
-end ""
-inline "#"

commandbreaker
";"
		
codebracket
-start "\{"
-end "\}"';
$forPlus = '

comment
-start "\/\*"
-end "\*\/"
-inline "#|(?=\/\/)"

commandbreaker
";"
		
codebracket
-start "\{"
-end "\}"

';
writeDescription($forPerl);
system('perl form.pl form.pl > 1');
writeDescription($forPlus);
system('perl form.pl code.txt > 2');
system('perl 1 code.txt > 3');
ok(getCode(3) eq getCode(2));
system('del 1 2 3');
done_testing();