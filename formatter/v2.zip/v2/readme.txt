######
Usage:
######

perl form.pl <name of file which would be formatted>

######
Result:
######

formatted code in file "formatted_<name of formatted file>" and
in terminal

######
Test:
######

perl test.pl

It format "code.txt"(c++), and its own("form.pl"), after that "formatted_form.pl" formatting "code.txt",
and results of formatting "code.txt" by 2 programms i compared


######
If you haven't got description:
######
example of description:
this text must be in file "description"
please ecranize symbols in "" if it's special symbol in perl
example for c++

comment
-start "\/\*"
-end "\*\/"
-inline "#"

commandbreaker
";"

codebracket
-start "\{"
-end "\}"